'use strict'
module.exports = {
    Cases: [
        {
            userContent: ``,
            assistantContent: ``
        },
        {
            userContent: ``,
            assistantContent: ``
        },
        {
            userContent: ``,
            assistantContent: ``
        },
        {
            userContent: ``,
            assistantContent: ``
        },
    ]
}